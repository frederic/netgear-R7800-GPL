opkdir = "/tmp/opk"
offline_root = "/tmp/opkg"
opkgcl = "/home/grg/opkg/code/svn/src/opkg-cl"
