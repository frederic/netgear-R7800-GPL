#ifndef COLDPLUG2_H
#define COLDPLUG2_H 1

#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#define SYSFS_PATH "/sys"

#endif /* COLDPLUG2_H */
