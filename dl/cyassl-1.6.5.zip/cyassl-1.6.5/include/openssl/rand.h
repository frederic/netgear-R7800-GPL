/* rand.h for openSSL */

#include "openssl/ssl.h"

