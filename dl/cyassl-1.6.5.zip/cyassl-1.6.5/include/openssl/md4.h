/* md4.h for libcurl */
