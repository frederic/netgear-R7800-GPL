/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#define inttostr offtostr
#define inttype off_t
#define inttype_is_signed 1
#include "inttostr.c"
