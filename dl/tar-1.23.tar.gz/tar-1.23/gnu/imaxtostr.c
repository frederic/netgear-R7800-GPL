/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#define inttostr imaxtostr
#define inttype intmax_t
#define inttype_is_signed 1
#include "inttostr.c"
